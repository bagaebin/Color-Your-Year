class Bg {
    constructor() {
        this.bgSize = dist(sunPosX, windowWidth, sunPosY, 0) * 2;

        this.bgColPt = [];
        this.bgRPt = [];
        this.bgGPt = [];
        this.bgBPt = [];
        this.bgRPlus = [];
        this.bgGPlus = [];
        this.bgBPlus = [];

        this.bgColPtPos = [];
        // change 1 to 0 after the test
        this.bgColPtPos[0] = 0;
        this.bgColPtPos[1] = this.bgSize * 0.33;
        this.bgColPtPos[2] = this.bgSize * 0.66;
        this.bgColPtPos[3] = this.bgSize;

        this.bgCol = [];
        this.bgColPos = [];

        this.count = 0;
    }

    setValue() {
        for (let i = 0; i < colCount; i++) {
            this.bgColPt[i] = color(0, 0, 0, 0);
            this.bgRPt[i] = color(0, 0, 0, 0);
            this.bgGPt[i] = color(0, 0, 0, 0);
            this.bgBPt[i] = color(0, 0, 0, 0);
        }
        this.bgColPt[0] = color(255, 255, 255, 0);

        for (let i = 0; i * 8 < this.bgSize; i++) {
            this.bgCol[i] = color(0, 0, 0, 0);;
            this.bgColPos[i] = 0;
        }

        for (let i = 0; i < colCount; i++) {
            this.bgRPlus[i] = 32;
            this.bgGPlus[i] = 32;
            this.bgBPlus[i] = 32;
        }
    }

    draw() {
        for (let i = 0; i * 8 < this.bgSize; i++) {
            push();
            smooth();
            ellipseMode(CENTER);
            noFill();
            strokeWeight(32);
            stroke(this.bgCol[i]);
            ellipse(sunPosX, sunPosY, i * 8, i * 8);
            pop();
        }
    }

    setGradient() {
        if (this.count * 8 < this.bgColPtPos[1]) {
            this.bgColPos[this.count] = map(this.count * 8, this.bgColPtPos[0], this.bgColPtPos[1], 0, 1);
            this.bgCol[this.count] = lerpColor(this.bgColPt[0], this.bgColPt[1], this.bgColPos[this.count]);
        }
        else if (this.bgColPtPos[1] < this.count * 8 < this.bgColPtPos[2]) {
            this.bgColPos[this.count] = map(this.count * 8, this.bgColPtPos[1], this.bgColPtPos[2], 0, 1);
            this.bgCol[this.count] = lerpColor(this.bgColPt[1], this.bgColPt[2], this.bgColPos[this.count]);
        }
        else if (this.bgColPtPos[2] < this.count * 8 < this.bgColPtPos[3]) {
            this.bgColPos[this.count] = map(this.count * 8, this.bgColPtPos[2], this.bgColPtPos[3], 0, 1);
            this.bgCol[this.count] = lerpColor(this.bgColPt[2], this.bgColPt[3], this.bgColPos[this.count]);

        }
        if (this.count * 8 < this.bgColPtPos[3]) {
            this.count++;
        }
        // console.log(this.bgColPos[10]);
        // console.log(this.bgCol[10]);
    }

    setPoint() {
        this.bgColPt[colNum] = pickedCol[colNum];
        this.bgColPt[colNum].setAlpha(64);
        for (let i = 0; i < colNum; i++) {
            if(red(this.bgColPt[i])>green(this.bgColPt[i])&&red(this.bgColPt[i])>blue(this.bgColPt[i])){
                this.bgRPlus[i]=64;
            }
            else if(green(this.bgColPt[i])>red(this.bgColPt[i])&&green(this.bgColPt[i])>blue(this.bgColPt[i])){
                this.bgGPlus[i]=64;
            }
            else if(blue(this.bgColPt[i])>red(this.bgColPt[i])&&blue(this.bgColPt[i])>green(this.bgColPt[i])){
                this.bgBPlus[i]=64;
            }
        }
        if (colNum > 0) {
            this.bgColPt[(colNum - 1)].setRed(red(this.bgColPt[(colNum - 1)]) + this.bgRPlus[(colNum-1)]);
            this.bgColPt[(colNum - 1)].setGreen(green(this.bgColPt[(colNum - 1)]) + this.bgGPlus[(colNum-1)]);
            this.bgColPt[(colNum - 1)].setBlue(blue(this.bgColPt[(colNum - 1)]) + this.bgBPlus[(colNum-1)]);
        }
        if (colNum > 1) {
            this.bgColPt[(colNum - 2)].setRed(red(this.bgColPt[(colNum - 2)]) + this.bgRPlus[(colNum-2)]);
            this.bgColPt[(colNum - 2)].setGreen(green(this.bgColPt[(colNum - 2)]) + this.bgGPlus[(colNum-2)]);
            this.bgColPt[(colNum - 2)].setBlue(blue(this.bgColPt[(colNum - 2)]) + this.bgBPlus[(colNum-2)]);
        }
    }
}