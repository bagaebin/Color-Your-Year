class Sun {
    constructor(cam, camSource, x, y, sc, ar) {
        this.cam = cam;
        this.camSource = camSource;
        this.x = x;
        this.y = y;
        this.sc = sc;
        this.ar = ar;
    }

    draw() {
        drawingContext.save(); // Save before clipping mask so you can undo it later on. ALWAYS DO THIS BEFORE TRANSLATIONS.
        push();
        fill(255);
        noStroke();
        circle(sunPosX+xMotion/3, sunPosY+yMotion/3, sunSc);
        pop();
        drawingContext.clip();
        push();
        imageMode(CENTER);
        scale(-1, 1);
        image(cam, -(sunPosX+xMotion/3), sunPosY+yMotion/3, sunSc * camAr, sunSc);
        pop();
        drawingContext.restore();
    }

    recreate(){
          //create a video capture object
  // cam = createCapture(VIDEO);
  cam = createCapture(this.camSource);

  //the createCapture() function creates an HTML video tag
  //as well as pulls up image to be used in p5 canvas
  //hide() function hides the HTML video element
  cam.hide();
    }
}