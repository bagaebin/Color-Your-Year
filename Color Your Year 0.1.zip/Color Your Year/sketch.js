/**
 * password input & massage box
 */
var pwInput;
var button;
var dear;
var msg;
let dearTxt = 'null';
let msgTxt = 'null';

let buttonColorOff = '#aaaaaa';
let buttonColorOn = '#6e6e6e';

/**
 * images
 */
let mountain;
let rabbit;

/**
 * objects
 */
let bg;
let sun;

let mountain1;
let mountain2;

let rabbitObj = [];

/** 
 * multiply value for responsive arrangement
*/
// blank space around the button and the msg etc
let blkX;

// set the size of the radial gradient of the bg

let mountain1PosX;
let mountain1PosY;
let mountain2PosX;
let mountain2PosY;
let mountain1Sc;
let mountain2Sc;

let rabbitSc;

let rabbitCount;
//set the interval(pos) of the rabbit objects
let rabbitUnitX;
let rabbitUnitY;

let sunPosX;
let sunPosY;
let sunSc;

//check capturing
let picking = false;

let colCount = 3;
let colNum = 0;

let pickedCol = [];

/** 
 * camera
*/
let cam;

//multiply the height to keep the set scale
let windowAr;
//to adjust cam ratio
let camAr;

let zMotion;
let xMotion;
let yMotion;

/**
 * making tilt request allowed
 */
// tilt and rotation for enabled devices
// on a desktop nothing will happen, but it wont break
// variables allow motion and ios to be detected.
// further code to detect a compass and tilt hardware on non-ios devices needed

let motion = false;
let ios = false;

// below code is essential for ios13 and above. 
// A click is needed for the device to request permission 
if (typeof DeviceMotionEvent.requestPermission === 'function') {
  document.body.addEventListener('click', function () {
    DeviceMotionEvent.requestPermission()
      .then(function () {
        console.log('DeviceMotionEvent enabled');

        motion = true;
        ios = true;
      })
      .catch(function (error) {
        console.warn('DeviceMotionEvent not enabled', error);
      })
  })
} else {
  // we are not on ios13 and above
  // todo
  // add detection for hardware for other devices
  // if(got the hardware) {
  // motion = true;
  // }
}

/**
 * preload images
 */
function preload() {
  mountain = loadImage('assets/mountainImg.png');
  rabbit = loadImage('assets/rabbitImg.png');
}

function setup() {
  frameRate(24);

  createCanvas(windowWidth, windowHeight);
  windowAr = windowHeight / windowWidth;

  //set back camera on phone
  var constraints = {
    audio: false,
    video: {
      facingMode: {
        exact: "environment"
      }
    }
    //video: {
    //facingMode: "user"
    //} 
  };

  //create a video capture object
  // cam = createCapture(VIDEO);
  cam = createCapture(constraints);

  //the createCapture() function creates an HTML video tag
  //as well as pulls up image to be used in p5 canvas
  //hide() function hides the HTML video element
  cam.hide();

  camAr = cam.width / cam.height;

  // setup() waits until preload() is done
  mountain.loadPixels();
  rabbit.loadPixels();

  setValue();

  /**
   * create graphic objects
   */
  bg = new Bg();
  bg.setValue();

  sun = new Sun(cam, constraints, sunPosX, sunPosY, sunSc, camAr);
  mountain1 = new Mountain(mountain1PosX, mountain1PosY, mountain1Sc);
  mountain2 = new Mountain(mountain2PosX, mountain2PosY, mountain2Sc);

  let index = 0;
  for (let i = 0; i < rabbitCount; i++) {
    rabbitObj[index++] = new Rabbit(
      20 + (i * rabbitUnitX),
      windowHeight - 20 - ((i + 1) * rabbitUnitY),
      rabbitUnitX / 2,
      rabbitUnitY / 2,
      rabbitUnitX,
      rabbitUnitY,
      random(0.5, 4),
      rabbitSc,
      i
    )
  }

  /**
   * craete input box and done button
   */
  push();
  pwInput = createInput('비밀번호를 적어주세요');
  pwInput.position(windowWidth / 2 - 100, windowHeight / 2 - 70);
  pwInput.size(240, 50);
  pwInput.style('border', '0');
  pwInput.style('border-radius', '25px');
  pwInput.style('outline', 'none');
  pwInput.style('font-family', 'Pretendard-Regular');
  pwInput.style('font-size', '16px');
  pwInput.style('text-align', 'center');
  pop();

  push();
  button = createButton('새해 받기');
  button.position(windowWidth / 2 - 100, windowHeight / 2 - 10);
  button.size(240, 40);
  button.style('border', '0');
  button.style('border-radius', '20px');
  button.style('outline', 'none');
  button.style('background-color', buttonColorOff);
  button.mouseOver(() => button.style('background-color:' + buttonColorOn));
  button.mouseOut(() => button.style('background-color:' + buttonColorOff));
  button.style('font-family', 'Pretendard-Regular');
  button.style('font-size', '16px');
  button.style('text-align', 'center');
  pop();
}

function draw() {
  /**
   * brighting bg
   */
  background(0);
  bg.setGradient();
  bg.draw();

  /**
   * check entered password and show fit massage
   */
  button.mousePressed(txt);

  /**
  * tilt motion
  */
  // the below code ensures a smooth transition from 0-180 and back
  zMotion = round(abs(radians(rotationZ) - PI))
  // x and y values moved from the centre point
  yMotion = round( rotationX * 10)
  xMotion = round(rotationY * 10)

  /**
 * camera sun
 */
  sun.draw();

  /**
   * moving rabbit
   */
  for (let i = 0; i < rabbitCount; i++) {
    rabbitObj[i].move();
    rabbitObj[i].draw();
  }

  /**
   * tilting mountain
   */
  mountain1.draw();
  mountain2.draw();
}

function mouseClicked() {
  if (!picking) {
    picking = true;
    pickColor();
    bg.count = 0;

    sun.recreate();
    picking = false;
  }
}

function pickColor() {
  if (colNum < colCount) {
    // pickedColor[colorNum] = cam.get(sunPosX + (sunSc*camAr / 2), sunPosY + (sunSc / 2));
    pickedCol[colNum] = color(cam.get(cam.width / 2, cam.height / 2));
    bg.setPoint();
    colNum++;

    // check connecting the picked cols
    console.log(pickedCol[0], pickedCol[1], pickedCol[2]);
    console.log(bg.bgColPt[0], bg.bgColPt[1], bg.bgColPt[2]);
  }
}

function txt() {
  txtData();

  dear = createP(dearTxt + ' 에게');
  dear.position(windowWidth * blkX, windowHeight * 0.1);
  dear.style('color', '#000000');
  dear.style('font-family', 'Pretendard-Regular');
  dear.style('font-size', '16px');
  msg = createP(msgTxt);
  msg.position(windowWidth * blkX, windowHeight * 0.1 + 40);
  msg.size(windowWidth * (1 - blkX * 2), windowHeight * 0.8 - 40)
  msg.style('color', '#000000');
  msg.style('font-family', 'Pretendard-Regular');
  msg.style('font-size', '16px');
  msg.style('line-height', '24px');

  pwInput.remove();
  button.remove();
}

function setValue() {
  /** 
 * graphic arrangement in horizontal mode
 */
  if (windowWidth > windowHeight) {
    blkX = 0.25;

    mountain1PosX = windowWidth * 0.1;
    mountain1PosY = windowHeight - (windowWidth * 0.33 * 0.5);
    mountain1Sc = windowWidth * 0.33;
    mountain2PosX = windowWidth * 0.3;
    mountain2PosY = windowHeight - (windowWidth * 0.5 * 0.5);
    mountain2Sc = windowWidth * 0.5;

    sunPosY = mountain1PosY * 1.1;
    sunSc = windowWidth * 0.125;

    rabbitSc = windowWidth * random(0.075, 0.1);
  }

  //graphic arrangement in vertical mode
  if (windowWidth < windowHeight) {
    blkX = 0.1;

    mountain1PosX = -(windowHeight * 0.1);
    mountain1PosY = windowHeight - (windowWidth * 0.66 * 0.5);
    mountain1Sc = windowWidth * 0.66;
    mountain2PosX = windowWidth - (windowWidth * 0.8);
    mountain2PosY = windowHeight - (windowWidth * 0.5);
    mountain2Sc = windowWidth;

    sunPosY = mountain1PosY * 1.025;
    sunSc = windowWidth * 0.3;

    rabbitSc = windowWidth * random(0.15, 0.175);
  }

  sunPosX = (mountain1PosX + mountain1Sc + mountain2PosX) / 2;

  //set the count and the pos of the rabbit objects
  rabbitCount = 4;
  rabbitUnitX = (windowWidth - 40) / rabbitCount;
  rabbitUnitY = (windowHeight - 40) * 0.6 / rabbitCount;
  // rabbitUnitY = (windowHeight - 40)*0.5 / rabbitCount;

  // set the basic col
  for (let i = 0; i < colCount; i++) {
    pickedCol[i] = color(0, 0, 0, 0);
  }
}

function txtData() {
  //test
  if (pwInput.value() == '0000') {
    dearTxt = '아무개';
    msgTxt =
      '안녕하세요';
  }

  else {
    dearTxt = '';
    msgTxt = '잘못된 비밀번호입니다. 다시 입력해보시거나 문의해주세요!';
  }
}