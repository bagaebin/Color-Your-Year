class Rabbit {
    constructor(xOff, yOff, x, y, unitX, unitY, speed, s, num) {
        this.xOff = xOff;
        this.yOff = yOff;
        this.x = x;
        this.y = y;
        this.unitX = unitX;
        this.unitY = unitY;
        this.speed = speed;
        this.ySpeed = 1
        this.xDir = -1;
        this.yDir = -1;

        this.sc = s;
        //multiply the heigth to keep the set size
        this.ar = rabbit.height / rabbit.width;

        this.num = num;

        this.turn = false;
        this.turning = 1;
        this.posSet = 1;
    }

    move() {
        this.x = this.x + this.speed * this.xDir;
        this.y = this.y + this.ySpeed * this.yDir;
        this.x= this.x+ xMotion;
        this.y=this.y+yMotion;
        if (this.x >= 20 + (rabbitCount - this.num) * this.unitX + this.sc || this.x <= -(20 + this.num * this.unitX + this.sc)) {
            this.xDir *= -1;
            this.x = this.x + 1 * this.xDir;
            this.turn = true
            this.turning *= -1;
        }
        if (this.y >= this.unitY || this.y <= 0) {
            this.yDir *= -1;
            this.y = this.y + this.ySpeed * this.yDir;
            if (this.yDir == 1) {
                this.ySpeed -= 0.3;
            }
            else if (this.yDir == -1) {
                this.ySpeed += 0.3;
            }
        }
    }

    draw() {
        push();
        imageMode(CENTER);
        if (this.turn) {
            this.posSet *= -1;
            this.turn = false;
        }
        if (this.turning == -1) {
            scale(-1, 1);
        }

        image(rabbit, (this.xOff + this.x) * this.posSet, this.yOff + this.y, this.sc, this.sc * this.ar);
        pop();
    }
}