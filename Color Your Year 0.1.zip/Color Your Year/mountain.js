class Mountain {
    constructor(x, y, s) {
        this.posX = x;
        this.posY = y;
        this.sc = s;

        //multiply height to keep the size set on the width
        this.ar = 0.5;
    }

    draw() {
        image(mountain, this.posX+xMotion/2, this.posY+yMotion/2, this.sc, this.sc * this.ar)
    }

    move() {

    }
}